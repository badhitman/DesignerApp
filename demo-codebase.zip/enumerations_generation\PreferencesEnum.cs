﻿////////////////////////////////////////////////
// Project: По умолчанию - by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

namespace PoUmolchaniyu
{
	/// <summary>
	/// Preference
	/// </summary>
	public enum PreferencesEnum
	{
		/// <summary>
		/// One
		/// </summary>
		One,

		/// <summary>
		/// Two
		/// </summary>
		Two,

		/// <summary>
		/// Three
		/// </summary>
		Three,
	}
}