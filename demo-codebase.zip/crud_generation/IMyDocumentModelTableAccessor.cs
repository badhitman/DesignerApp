﻿////////////////////////////////////////////////
// Project: По умолчанию - by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using SharedLib;

namespace PoUmolchaniyu
{
	/// <summary>
	/// Demo
	/// </summary>
	public partial interface IMyDocumentModelTableAccessor
	{
		#region main
		/// <summary>
		/// Создать перечень новых объектов: 'Demo'
		/// </summary>
		/// <param name="obj_range">Объекты добавления в БД</param>
		public Task AddAsync(IEnumerable<MyDocumentModel> obj_range);

		/// <summary>
		/// Прочитать перечень объектов: 'Demo'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		public Task<List<MyDocumentModel>> ReadAsync(IEnumerable<int> ids);

		/// <summary>
		/// Получить (порцию/pagination) объектов: 'Demo'
		/// </summary>
		/// <param name="pagination_request">Запрос-пагинатор</param>
		public Task<TPaginationResponseModel<MyDocumentModel>> SelectAsync(PaginationRequestModel pagination_request);

		/// <summary>
		/// Обновить перечень объектов: 'Demo'
		/// </summary>
		/// <param name="obj_range">Объекты обновления в БД</param>
		public Task UpdateAsync(IEnumerable<MyDocumentModel> obj_range);

		/// <summary>
		/// Удалить перечень объектов: 'Demo'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		public Task RemoveAsync(IEnumerable<int> ids);
		/// <summary>
		/// Инверсия признака деактивации объекта: 'Demo'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		/// <param name="set_mark">Признак, который следует установить</param>
		public Task MarkDeleteToggleAsync(IEnumerable<int> ids, bool set_mark);

		#endregion
		#region ext parts
		/// <summary>
		/// Создать перечень новых объектов: 'Demo seed' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="obj_range">Объекты добавления в БД</param>
		public Task AddFormDemoFirstTabMyDocumentModelAsync(IEnumerable<FormDemoFirstTabMyDocumentModel> obj_range);

		/// <summary>
		/// Прочитать перечень объектов: 'Demo seed' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		public Task<List<FormDemoFirstTabMyDocumentModel>> ReadFormDemoFirstTabMyDocumentModelAsync(IEnumerable<int> ids);

		/// <summary>
		/// Получить (порцию/pagination) объектов: 'Demo seed' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="pagination_request">Запрос-пагинатор</param>
		public Task<TPaginationResponseModel<FormDemoFirstTabMyDocumentModel>> SelectFormDemoFirstTabMyDocumentModelAsync(PaginationRequestModel pagination_request);

		/// <summary>
		/// Обновить перечень объектов: 'Demo seed' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="obj_range">Объекты обновления в БД</param>
		public Task UpdateFormDemoFirstTabMyDocumentModelAsync(IEnumerable<FormDemoFirstTabMyDocumentModel> obj_range);

		/// <summary>
		/// Удалить перечень объектов: 'Demo seed' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		public Task RemoveFormDemoFirstTabMyDocumentModelAsync(IEnumerable<int> ids);
		#endregion
	}
}