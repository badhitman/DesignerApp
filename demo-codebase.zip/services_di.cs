﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using Microsoft.Extensions.DependencyInjection;

namespace BlazorWebLib
{
	/// <summary>
	/// По умолчанию
	/// </summary>
	/// <remarks>
	/// di services
	/// </remarks>
	public static class ServicesExtensionDesignerDI
	{
		/// Регистрация сервисов
		public static void BuildDesignerServicesDI(this IServiceCollection services)
		{
			services.AddScoped<IDemoDocumentTableAccessor, DemoDocumentTableAccessor>();
		}
	}
}