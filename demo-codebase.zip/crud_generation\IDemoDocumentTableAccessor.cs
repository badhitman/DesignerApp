﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using SharedLib;

namespace PoUmolchaniyu
{
	/// <summary>
	/// Demo document
	/// </summary>
	public partial interface IDemoDocumentTableAccessor
	{
		#region main
		///<inheritdoc/>
		public Task AddAsync(IEnumerable<DemoDocument> obj_range);

		///<inheritdoc/>
		public Task<List<DemoDocument>> ReadAsync(IEnumerable<int> ids);

		///<inheritdoc/>
		public Task<TPaginationResponseModel<DemoDocument>> SelectAsync(PaginationRequestModel pagination_request);

		///<inheritdoc/>
		public Task UpdateAsync(IEnumerable<DemoDocument> obj_range);

		///<inheritdoc/>
		public Task RemoveAsync(IEnumerable<int> ids);
		///<inheritdoc/>
		public Task MarkDeleteToggleAsync(IEnumerable<int> ids, bool set_mark);
		#endregion

		#region tables parts
		///<inheritdoc/>
		public Task AddBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<BootstrapFormDemo1DemoTab2DemoDocument> obj_range);

		///<inheritdoc/>
		public Task<List<BootstrapFormDemo1DemoTab2DemoDocument>> ReadBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<int> ids);

		///<inheritdoc/>
		public Task<TPaginationResponseModel<BootstrapFormDemo1DemoTab2DemoDocument>> SelectBootstrapFormDemo1DemoTab2DemoDocumentAsync(PaginationRequestModel pagination_request);

		///<inheritdoc/>
		public Task UpdateBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<BootstrapFormDemo1DemoTab2DemoDocument> obj_range);

		///<inheritdoc/>
		public Task RemoveBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<int> ids);
		#endregion
	}
}