﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using SharedLib;

namespace BlazorWebLib
{
	/// <summary>
	/// Demo document
	/// </summary>
	public partial interface IDemoDocumentTableAccessor
	{
		#region main
		/// <summary>
		/// Создать перечень новых объектов: 'Demo document'
		/// </summary>
		/// <param name="obj_range">Объекты добавления в БД</param>
		public Task AddAsync(IEnumerable<DemoDocument> obj_range);

		/// <summary>
		/// Прочитать перечень объектов: 'Demo document'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		public Task<List<DemoDocument>> ReadAsync(IEnumerable<int> ids);

		/// <summary>
		/// Получить (порцию/pagination) объектов: 'Demo document'
		/// </summary>
		/// <param name="pagination_request">Запрос-пагинатор</param>
		public Task<TPaginationResponseModel<DemoDocument>> SelectAsync(PaginationRequestModel pagination_request);

		/// <summary>
		/// Удалить перечень объектов: 'Demo document'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		public Task RemoveAsync(IEnumerable<int> ids);

		/// <summary>
		/// Инверсия признака деактивации объекта: 'Demo document'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		/// <param name="set_mark">Признак, который следует установить</param>
		public Task MarkDeleteToggleAsync(IEnumerable<int> ids, bool set_mark);
		#endregion

		#region tables
		/// <summary>
		/// Создать перечень новых объектов: 'Demo tab 2' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="obj_range">Объекты добавления в БД</param>
		public Task AddBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<BootstrapFormDemo1DemoTab2DemoDocument> obj_range);

		/// <summary>
		/// Прочитать перечень объектов: 'Demo tab 2' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		public Task<List<BootstrapFormDemo1DemoTab2DemoDocument>> ReadBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<int> ids);

		/// <summary>
		/// Получить (порцию/pagination) объектов: 'Demo tab 2' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="pagination_request">Запрос-пагинатор</param>
		public Task<TPaginationResponseModel<BootstrapFormDemo1DemoTab2DemoDocument>> SelectBootstrapFormDemo1DemoTab2DemoDocumentAsync(PaginationRequestModel pagination_request);

		/// <summary>
		/// Обновить перечень объектов: 'Demo tab 2' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="obj_range">Объекты обновления в БД</param>
		public Task UpdateBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<BootstrapFormDemo1DemoTab2DemoDocument> obj_range);

		/// <summary>
		/// Удалить перечень объектов: 'Demo tab 2' - 'Bootstrap form (demo 1)'
		/// </summary>
		/// <param name="ids">Идентификаторы объектов</param>
		public Task RemoveBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<int> ids);
		#endregion
	}
}