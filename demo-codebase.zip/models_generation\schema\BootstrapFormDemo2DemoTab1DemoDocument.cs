﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using System.ComponentModel.DataAnnotations;

namespace BlazorWebLib
{
	/// <summary>
	/// Demo tab 1
	/// </summary>
	public partial class BootstrapFormDemo2DemoTab1DemoDocument
	{
		/// <summary>
		/// Идентификатор/Key
		/// </summary>
		[Key]
		public int Id { get; set; }

		/// <summary>
		/// [FK: Документ]
		/// </summary>
		public int DocumentId { get; set; }
		/// <summary>
		/// Документ
		/// </summary>
		public DemoDocument? Document { get; set; }

		/// <summary>
		/// Email
		/// </summary>
		public string? Email { get; set; }

		/// <summary>
		/// Password
		/// </summary>
		public string? Password { get; set; }

		/// <summary>
		/// Address
		/// </summary>
		public string? Address { get; set; }

		/// <summary>
		/// Address 2
		/// </summary>
		public string? Address2 { get; set; }

		/// <summary>
		/// City
		/// </summary>
		public string? City { get; set; }

		/// <summary>
		/// Zip
		/// </summary>
		public string? Zip { get; set; }

		/// <summary>
		/// Check me out
		/// </summary>
		public bool? CheckMeOut { get; set; }

		/// <summary>
		/// State
		/// </summary>
		public Preference? State { get; set; }
	}
}