﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using System.ComponentModel.DataAnnotations;

namespace PoUmolchaniyu
{
	/// <summary>
	/// Demo tab 2
	/// </summary>
	public partial class BootstrapFormDemo1DemoTab2DemoDocument
	{
		/// <summary>
		/// Идентификатор/Key
		/// </summary>
		[Key]
		public int Id { get; set; }

		/// <summary>
		/// [FK: Документ]
		/// </summary>
		public int DocumentId { get; set; }
		/// <summary>
		/// Документ
		/// </summary>
		public DemoDocument? Document { get; set; }

		/// <summary>
		/// Test text
		/// </summary>
		public string? TestText { get; set; }

		/// <summary>
		/// Test Directory
		/// </summary>
		public List<BulevoLogicheskoeMultipleBootstrapFormDemo1DemoTab2DemoDocument>? TestDirectory { get; set; }
	}
}