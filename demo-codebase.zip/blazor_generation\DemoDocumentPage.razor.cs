﻿////////////////////////////////////////////////
// © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

namespace BlazorLib.blazor_generation;

/// <summary>
/// [doc: 'Demo document' `DemoDocument`]
/// </summary>
public partial class DemoDocumentPage : BlazorLib.BlazorBusyComponentBaseModel
{
	// TODO: xxx
}