﻿////////////////////////////////////////////////
// © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using Microsoft.AspNetCore.Components;

namespace BlazorLib.blazor_generation;

/// <summary>
/// [doc: 'Demo document' `DemoDocument`]
/// </summary>
public partial class DemoDocumentPage : BlazorBusyComponentBaseModel
{
	[Parameter]
	public int? Id { get; set; }

}