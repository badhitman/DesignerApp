﻿////////////////////////////////////////////////
// © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using Microsoft.AspNetCore.Components;

namespace BlazorLib.blazor_generation;

/// <summary>
/// [doc: 'Demo document' `DemoDocument`]
/// </summary>
public partial class DemoDocumentPage : BlazorBusyComponentBaseModel
{
	/// <summary>
	/// Идентификатор объекта-документа. Если null - тогда создание нового
	/// </summary>
	[Parameter]
	public int? Id { get; set; }

}