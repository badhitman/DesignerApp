﻿////////////////////////////////////////////////
// Project: По умолчанию - by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using System.ComponentModel.DataAnnotations;

namespace PoUmolchaniyu
{
	/// <summary>
	/// New tab
	/// </summary>
	public partial class DemoFormSecondTabMyDocumentModel
	{
		/// <summary>
		/// Идентификатор/Key
		/// </summary>
		[Key]
		public int Id { get; set; }

		/// <summary>
		/// [FK: Документ]
		/// </summary>
		public int DocumentId { get; set; }
		/// <summary>
		/// Документ
		/// </summary>
		public MyDocumentModel? Document { get; set; }

		/// <summary>
		/// Test text
		/// </summary>
		public string? TestText { get; set; }

		/// <summary>
		/// Test Directory
		/// </summary>
		public PreferencesEnum? TestDirectory { get; set; }
	}
}