﻿////////////////////////////////////////////////
// Project: По умолчанию - by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

namespace PoUmolchaniyu
{
	/// <summary>
	/// Demo
	/// </summary>
	public partial class MyDocumentModel : SharedLib.IdSwitchableModel
	{
		/// <summary>
		/// [tab: Demo seed][form: Bootstrap form (demo 1)]
		/// </summary>
		public List<FormDemoFirstTabMyDocumentModel>? FormDemoFirstTabMyDocumentModelDataMultiSet { get; set; }

		/// <summary>
		/// [tab: Demo seed][form: Bootstrap form (demo 2)]
		/// </summary>
		public BootstrapFormFirstTabMyDocumentModel? BootstrapFormFirstTabMyDocumentModelDataSingleSet { get; set; }

		/// <summary>
		/// [tab: New tab][form: Bootstrap form (demo 1)]
		/// </summary>
		public DemoFormSecondTabMyDocumentModel? DemoFormSecondTabMyDocumentModelDataSingleSet { get; set; }
	}
}