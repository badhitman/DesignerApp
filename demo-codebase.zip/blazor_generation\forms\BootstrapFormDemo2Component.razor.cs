﻿////////////////////////////////////////////////
// © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using Microsoft.AspNetCore.Components;

namespace BlazorLib.blazor_generation.forms;

/// <summary>
/// [doc: 'Demo document' `DemoDocument`] [tab: 'Demo tab 1' `DemoTab1`] [form: 'Bootstrap form (demo 2)' `BootstrapFormDemo2`]
/// </summary>
public partial class BootstrapFormDemo2Component : BlazorBusyComponentBaseModel
{

}