﻿////////////////////////////////////////////////
// Project: По умолчанию - by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using Microsoft.EntityFrameworkCore;
using SharedLib;

namespace PoUmolchaniyu
{
	/// <summary>
	/// Demo
	/// </summary>
	public partial class MyDocumentModelTableAccessor(IDbContextFactory<LayerContext> appDbFactory) : IMyDocumentModelTableAccessor
	{
		/// <inheritdoc/>
		public async Task AddAsync(IEnumerable<MyDocumentModel> obj_range)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.AddRangeAsync(obj_range);
			await _db_context.SaveChangesAsync();
		}

		/// <inheritdoc/>
		public async Task<List<MyDocumentModel>> ReadAsync(IEnumerable<int> ids)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			return await _db_context.MyDocumentModelDbSet.Where(x => ids.Contains(x.Id)).ToListAsync();
		}

		/// <inheritdoc/>
		public async Task<TPaginationResponseModel<MyDocumentModel>> SelectAsync(PaginationRequestModel pagination_request)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			IQueryable<MyDocumentModel>? query = _db_context.MyDocumentModelDbSet.AsQueryable();
			TPaginationResponseModel<MyDocumentModel> result = new(pagination_request)
			{
				TotalRowsCount = await query.CountAsync()
			};
			switch (result.SortBy)
			{
				default:
					query = result.SortingDirection == VerticalDirectionsEnum.Up
						? query.OrderByDescending(x => x.Id)
						: query.OrderBy(x => x.Id);
					break;
			}
			query = query.Skip((result.PageNum - 1) * result.PageSize).Take(result.PageSize);
			result.Response = await query.ToListAsync();
			return result;
		}

		/// <inheritdoc/>
		public async Task UpdateAsync(IEnumerable<MyDocumentModel> obj_range)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			_db_context.Update(obj_range);
			await _db_context.SaveChangesAsync();
		}

		/// <inheritdoc/>
		public async Task RemoveAsync(IEnumerable<int> ids)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.MyDocumentModelDbSet.Where(x => ids.Contains(x.Id)).ExecuteDeleteAsync();
		}

		/// <inheritdoc/>
		public async Task MarkDeleteToggleAsync(IEnumerable<int> ids, bool set_mark)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.MyDocumentModelDbSet.Where(x => ids.Contains(x.Id)).ExecuteUpdateAsync(b => b.SetProperty(u => u.IsDisabled, set_mark));
		}

		/// <inheritdoc/>
		public async Task AddFormDemoFirstTabMyDocumentModelAsync(IEnumerable<FormDemoFirstTabMyDocumentModel> obj_range)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.AddRangeAsync(obj_range);
			await _db_context.SaveChangesAsync();
		}

		/// <inheritdoc/>
		public async Task<List<FormDemoFirstTabMyDocumentModel>> ReadFormDemoFirstTabMyDocumentModelAsync(IEnumerable<int> ids)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			return await _db_context.FormDemoFirstTabMyDocumentModelDbSet.Where(x => ids.Contains(x.Id)).ToListAsync();
		}

		/// <inheritdoc/>
		public async Task<TPaginationResponseModel<FormDemoFirstTabMyDocumentModel>> SelectFormDemoFirstTabMyDocumentModelAsync(PaginationRequestModel pagination_request)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			IQueryable<FormDemoFirstTabMyDocumentModel>? query = _db_context.FormDemoFirstTabMyDocumentModelDbSet.AsQueryable();
			TPaginationResponseModel<FormDemoFirstTabMyDocumentModel> result = new(pagination_request)
			{
				TotalRowsCount = await query.CountAsync()
			};
			switch (result.SortBy)
			{
				default:
					query = result.SortingDirection == VerticalDirectionsEnum.Up
						? query.OrderByDescending(x => x.Id)
						: query.OrderBy(x => x.Id);
					break;
			}
			query = query.Skip((result.PageNum - 1) * result.PageSize).Take(result.PageSize);
			result.Response = await query.ToListAsync();
			return result;
		}

		/// <inheritdoc/>
		public async Task UpdateFormDemoFirstTabMyDocumentModelAsync(IEnumerable<FormDemoFirstTabMyDocumentModel> obj_range)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			_db_context.Update(obj_range);
			await _db_context.SaveChangesAsync();
		}

		/// <inheritdoc/>
		public async Task RemoveFormDemoFirstTabMyDocumentModelAsync(IEnumerable<int> ids)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.FormDemoFirstTabMyDocumentModelDbSet.Where(x => ids.Contains(x.Id)).ExecuteDeleteAsync();
		}
	}
}