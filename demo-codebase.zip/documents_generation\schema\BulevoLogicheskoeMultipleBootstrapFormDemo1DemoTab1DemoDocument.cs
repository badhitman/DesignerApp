﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using System.ComponentModel.DataAnnotations;

namespace PoUmolchaniyu
{
	/// <summary>
	/// Demo tab 1
	/// </summary>
	public partial class BulevoLogicheskoeMultipleBootstrapFormDemo1DemoTab1DemoDocument
	{
		/// <summary>
		/// Идентификатор/Key
		/// </summary>
		[Key]
		public int Id { get; set; }

		/// <summary>
		/// [FK: Форма в табе]
		/// </summary>
		public int OwnerId { get; set; }
		/// <summary>
		/// Форма в табе
		/// </summary>
		public BootstrapFormDemo1DemoTab1DemoDocument? Owner { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public BulevoLogicheskoe TestDirectory { get; set; }
	}
}