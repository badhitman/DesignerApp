﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace BlazorWebLib
{
	/// <summary>
	/// [doc: 'Demo document' `DemoDocument`] [tab: 'Demo tab 1' `DemoTab1`] [form: 'Bootstrap form (demo 1)' `BootstrapFormDemo1`] [field: 'Test Directory' `TestDirectory`]
	/// </summary>
	[Index(nameof(OwnerId), nameof(TestDirectory), IsUnique = true)]
	public partial class BulevoLogicheskoeMultipleBootstrapFormDemo1DemoTab1DemoDocument
	{
		/// <summary>
		/// Идентификатор/Key
		/// </summary>
		[Key]
		public int Id { get; set; }

		/// <summary>
		/// [FK: Форма в табе]
		/// </summary>
		public int OwnerId { get; set; }
		/// <summary>
		/// Форма в табе
		/// </summary>
		public BootstrapFormDemo1DemoTab1DemoDocument? Owner { get; set; }

		/// <summary>
		/// Test Directory
		/// </summary>
		public BulevoLogicheskoe TestDirectory { get; set; }
	}
}