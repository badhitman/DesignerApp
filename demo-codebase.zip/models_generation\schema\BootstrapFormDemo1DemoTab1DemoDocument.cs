﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using System.ComponentModel.DataAnnotations;

namespace BlazorWebLib
{
	/// <summary>
	/// Demo tab 1
	/// </summary>
	public partial class BootstrapFormDemo1DemoTab1DemoDocument
	{
		/// <summary>
		/// Идентификатор/Key
		/// </summary>
		[Key]
		public int Id { get; set; }

		/// <summary>
		/// [FK: Документ]
		/// </summary>
		public int DocumentId { get; set; }
		/// <summary>
		/// Документ
		/// </summary>
		public DemoDocument? Document { get; set; }

		/// <summary>
		/// Test text
		/// </summary>
		public string? TestText { get; set; }

		/// <summary>
		/// Test Directory
		/// </summary>
		public List<BulevoLogicheskoeMultipleBootstrapFormDemo1DemoTab1DemoDocument>? TestDirectory { get; set; }
	}
}