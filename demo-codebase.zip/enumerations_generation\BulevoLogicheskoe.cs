﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

namespace BlazorWebLib
{
	/// <summary>
	/// Булево (логическое)
	/// </summary>
	public enum BulevoLogicheskoe
	{
		/// <summary>
		/// Да
		/// </summary>
		Da,

		/// <summary>
		/// Нет
		/// </summary>
		Net,
	}
}