﻿////////////////////////////////////////////////
// Project: По умолчанию - by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

namespace PoUmolchaniyu
{
	/// <summary>
	/// Булево (логическое)
	/// </summary>
	public enum BooleanEnum
	{
		/// <summary>
		/// Да
		/// </summary>
		Yes,

		/// <summary>
		/// Нет
		/// </summary>
		No,
	}
}