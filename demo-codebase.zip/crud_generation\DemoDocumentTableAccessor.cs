﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using Microsoft.EntityFrameworkCore;
using SharedLib;

namespace PoUmolchaniyu
{
	/// <summary>
	/// Demo document
	/// </summary>
	public partial class DemoDocumentTableAccessor(IDbContextFactory<LayerContext> appDbFactory) : IDemoDocumentTableAccessor
	{
		/// <inheritdoc/>
		public async Task AddAsync(IEnumerable<DemoDocument> obj_range)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.AddRangeAsync(obj_range);
			await _db_context.SaveChangesAsync();
		}

		/// <inheritdoc/>
		public async Task<List<DemoDocument>> ReadAsync(IEnumerable<int> ids)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			return await _db_context.DemoDocumentDbSet.Where(x => ids.Contains(x.Id)).ToListAsync();
		}

		/// <inheritdoc/>
		public async Task<TPaginationResponseModel<DemoDocument>> SelectAsync(PaginationRequestModel pagination_request)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			IQueryable<DemoDocument>? query = _db_context.DemoDocumentDbSet.AsQueryable();
			TPaginationResponseModel<DemoDocument> result = new(pagination_request)
			{
				TotalRowsCount = await query.CountAsync()
			};
			switch (result.SortBy)
			{
				default:
					query = result.SortingDirection == VerticalDirectionsEnum.Up
						? query.OrderByDescending(x => x.Id)
						: query.OrderBy(x => x.Id);
					break;
			}
			query = query.Skip((result.PageNum - 1) * result.PageSize).Take(result.PageSize);
			result.Response = await query.ToListAsync();
			return result;
		}

		/// <inheritdoc/>
		public async Task UpdateAsync(IEnumerable<DemoDocument> obj_range)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			_db_context.Update(obj_range);
			await _db_context.SaveChangesAsync();
		}

		/// <inheritdoc/>
		public async Task RemoveAsync(IEnumerable<int> ids)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.DemoDocumentDbSet.Where(x => ids.Contains(x.Id)).ExecuteDeleteAsync();
		}

		/// <inheritdoc/>
		public async Task MarkDeleteToggleAsync(IEnumerable<int> ids, bool set_mark)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.DemoDocumentDbSet.Where(x => ids.Contains(x.Id)).ExecuteUpdateAsync(b => b.SetProperty(u => u.IsDisabled, set_mark));
		}

		/// <inheritdoc/>
		public async Task AddBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<BootstrapFormDemo1DemoTab2DemoDocument> obj_range)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.AddRangeAsync(obj_range);
			await _db_context.SaveChangesAsync();
		}

		/// <inheritdoc/>
		public async Task<List<BootstrapFormDemo1DemoTab2DemoDocument>> ReadBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<int> ids)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			return await _db_context.BootstrapFormDemo1DemoTab2DemoDocumentDbSet.Where(x => ids.Contains(x.Id)).ToListAsync();
		}

		/// <inheritdoc/>
		public async Task<TPaginationResponseModel<BootstrapFormDemo1DemoTab2DemoDocument>> SelectBootstrapFormDemo1DemoTab2DemoDocumentAsync(PaginationRequestModel pagination_request)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			IQueryable<BootstrapFormDemo1DemoTab2DemoDocument>? query = _db_context.BootstrapFormDemo1DemoTab2DemoDocumentDbSet.AsQueryable();
			TPaginationResponseModel<BootstrapFormDemo1DemoTab2DemoDocument> result = new(pagination_request)
			{
				TotalRowsCount = await query.CountAsync()
			};
			switch (result.SortBy)
			{
				default:
					query = result.SortingDirection == VerticalDirectionsEnum.Up
						? query.OrderByDescending(x => x.Id)
						: query.OrderBy(x => x.Id);
					break;
			}
			query = query.Skip((result.PageNum - 1) * result.PageSize).Take(result.PageSize);
			result.Response = await query.ToListAsync();
			return result;
		}

		/// <inheritdoc/>
		public async Task UpdateBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<BootstrapFormDemo1DemoTab2DemoDocument> obj_range)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			_db_context.Update(obj_range);
			await _db_context.SaveChangesAsync();
		}

		/// <inheritdoc/>
		public async Task RemoveBootstrapFormDemo1DemoTab2DemoDocumentAsync(IEnumerable<int> ids)
		{
			using LayerContext _db_context = appDbFactory.CreateDbContext();
			await _db_context.BootstrapFormDemo1DemoTab2DemoDocumentDbSet.Where(x => ids.Contains(x.Id)).ExecuteDeleteAsync();
		}
	}
}