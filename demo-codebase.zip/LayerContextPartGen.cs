﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using Microsoft.EntityFrameworkCore;

namespace BlazorWebLib
{
	/// <summary>
	/// Database context
	/// </summary>
	public partial class LayerContext : DbContext
	{
		/// <summary>
		/// Demo document
		/// </summary>
		public DbSet<DemoDocument> DemoDocumentDbSet { get; set; }

#region schema
		/// <summary>
		/// ['Demo document' `DemoDocument`] ['Demo tab 1' `DemoTab1`] ['Bootstrap form (demo 1)' `BootstrapFormDemo1`]
		/// </summary>
		public DbSet<BootstrapFormDemo1DemoTab1DemoDocument> BootstrapFormDemo1DemoTab1DemoDocumentDbSet { get; set; }

#region multiselect enumerations
		/// <summary>
		/// ['Demo document' `DemoDocument`] ['Demo tab 1' `DemoTab1`] ['Bootstrap form (demo 1)' `BootstrapFormDemo1`] ['Test Directory' `TestDirectory`]
		/// </summary>
		public DbSet<BulevoLogicheskoeMultipleBootstrapFormDemo1DemoTab1DemoDocument> BulevoLogicheskoeMultipleBootstrapFormDemo1DemoTab1DemoDocumentDbSet { get; set; }
#endregion

		/// <summary>
		/// ['Demo document' `DemoDocument`] ['Demo tab 1' `DemoTab1`] ['Bootstrap form (demo 2)' `BootstrapFormDemo2`]
		/// </summary>
		public DbSet<BootstrapFormDemo2DemoTab1DemoDocument> BootstrapFormDemo2DemoTab1DemoDocumentDbSet { get; set; }

		/// <summary>
		/// ['Demo document' `DemoDocument`] ['Demo tab 2' `DemoTab2`] ['Bootstrap form (demo 1)' `BootstrapFormDemo1`]
		/// </summary>
		public DbSet<BootstrapFormDemo1DemoTab2DemoDocument> BootstrapFormDemo1DemoTab2DemoDocumentDbSet { get; set; }

#region multiselect enumerations
		/// <summary>
		/// ['Demo document' `DemoDocument`] ['Demo tab 2' `DemoTab2`] ['Bootstrap form (demo 1)' `BootstrapFormDemo1`] ['Test Directory' `TestDirectory`]
		/// </summary>
		public DbSet<BulevoLogicheskoeMultipleBootstrapFormDemo1DemoTab2DemoDocument> BulevoLogicheskoeMultipleBootstrapFormDemo1DemoTab2DemoDocumentDbSet { get; set; }
#endregion
#endregion
	}
}