﻿////////////////////////////////////////////////
// Project: По умолчанию - by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using Microsoft.EntityFrameworkCore;

namespace PoUmolchaniyu
{
	/// <summary>
	/// Database context
	/// </summary>
	public partial class LayerContext : DbContext
	{
		/// <summary>
		/// Demo
		/// </summary>
		public DbSet<MyDocumentModel> MyDocumentModelDbSet { get; set; }

#region schema for [MyDocumentModel]
		/// <summary>
		/// [Demo]->[Demo seed]->[Bootstrap form (demo 1)]
		/// </summary>
		public DbSet<FormDemoFirstTabMyDocumentModel> FormDemoFirstTabMyDocumentModelDbSet { get; set; }

		/// <summary>
		/// [Demo]->[Demo seed]->[Bootstrap form (demo 2)]
		/// </summary>
		public DbSet<BootstrapFormFirstTabMyDocumentModel> BootstrapFormFirstTabMyDocumentModelDbSet { get; set; }

		/// <summary>
		/// [Demo]->[New tab]->[Bootstrap form (demo 1)]
		/// </summary>
		public DbSet<DemoFormSecondTabMyDocumentModel> DemoFormSecondTabMyDocumentModelDbSet { get; set; }
#endregion
	}
}