﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

using Microsoft.EntityFrameworkCore;

namespace PoUmolchaniyu
{
	/// <summary>
	/// Database context
	/// </summary>
	public partial class LayerContext : DbContext
	{
		/// <summary>
		/// Demo document
		/// </summary>
		public DbSet<DemoDocument> DemoDocumentDbSet { get; set; }

#region schema for [DemoDocument]
		/// <summary>
		/// [Demo document]->[Demo tab 1]->[Bootstrap form (demo 1)]
		/// </summary>
		public DbSet<BootstrapFormDemo1DemoTab1DemoDocument> BootstrapFormDemo1DemoTab1DemoDocumentDbSet { get; set; }

		/// <summary>
		/// [Demo document]->[Demo tab 1]->[Bootstrap form (demo 2)]
		/// </summary>
		public DbSet<BootstrapFormDemo2DemoTab1DemoDocument> BootstrapFormDemo2DemoTab1DemoDocumentDbSet { get; set; }

		/// <summary>
		/// [Demo document]->[Demo tab 2]->[Bootstrap form (demo 1)]
		/// </summary>
		public DbSet<BootstrapFormDemo1DemoTab2DemoDocument> BootstrapFormDemo1DemoTab2DemoDocumentDbSet { get; set; }
#endregion
	}
}