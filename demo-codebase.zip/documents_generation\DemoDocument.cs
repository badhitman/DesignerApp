﻿////////////////////////////////////////////////
// Project: 'По умолчанию' by  © https://github.com/badhitman - @fakegov
////////////////////////////////////////////////

namespace PoUmolchaniyu
{
	/// <summary>
	/// Документ: 'Demo document'
	/// </summary>
	public partial class DemoDocument : SharedLib.IdSwitchableModel
	{
		/// <summary>
		/// [tab: Demo tab 1 `DemoTab1`][form: Bootstrap form (demo 1) `BootstrapFormDemo1`]
		/// </summary>
		public BootstrapFormDemo1DemoTab1DemoDocument? BootstrapFormDemo1DemoTab1DemoDocumentDataSingleSet { get; set; }

		/// <summary>
		/// [tab: Demo tab 1 `DemoTab1`][form: Bootstrap form (demo 2) `BootstrapFormDemo2`]
		/// </summary>
		public BootstrapFormDemo2DemoTab1DemoDocument? BootstrapFormDemo2DemoTab1DemoDocumentDataSingleSet { get; set; }

		/// <summary>
		/// [tab: Demo tab 2 `DemoTab2`][form: Bootstrap form (demo 1) `BootstrapFormDemo1`]
		/// </summary>
		public List<BootstrapFormDemo1DemoTab2DemoDocument>? BootstrapFormDemo1DemoTab2DemoDocumentDataMultiSet { get; set; }
	}
}