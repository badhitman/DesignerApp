﻿Генератор C# комплекта - ver: 1.0.0+6fc37a3b62c4b2e1190b40753c22f2dce1cc451a (by © https://github.com/badhitman - @fakegov)
'По умолчанию' `BlazorWebLib`
============ 30.07.2024 9:08:57 ============

Перечислений: 2 (элементов всего: 5)
Документов: 1 шт.
	вкладок (всего): 2
	форм (всего): 3
	полей (всего): 9 [simple field`s] + 3 [enumerations field`s]
- ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ -
blazor_generation        - папка Blazor UI
enumerations_generation          - папка перечислений
crud_generation    - папка файлов сервисов backend служб доступа к данным (CRUD) и классов/моделей ответов: интерфейсы (+ реализация) доступа к контексту таблиц базы данных для использования их в UI
××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××
Вспомогательные файлы (зависимости типов): 
	> models_generation/SelectJournalPartRequestModel.cs
	> models_generation/IJournalUniversalService.cs
	> blazor_generation/JournalUniversalComponent.razor (+ отдельный JournalUniversalComponent.razor.cs)
××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××
bottom-menu.Development.json  - навигация по созданным страницамLayerContextPartGen.cs        - разделяемый [public partial class LayerContext : DbContext] класс.
services_di.cs                - [public static class ServicesExtensionDesignerDI].[public static void BuildDesignerServicesDI(this IServiceCollection services)]
