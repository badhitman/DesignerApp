﻿Генератор C# комплекта - ver: 1.0.0+c61107d6dbb6d3bb1c950e2c9c9c0b27d8ea37e4 (by © https://github.com/badhitman - @fakegov)
'По умолчанию' `BlazorWebLib`
============ 25.07.2024 20:15:45 ============

Перечислений: 2 (элементов всего: 5)
Документов: 1 шт.
	вкладок (всего): 2
	форм (всего): 3
	полей (всего): 9 [simple field`s] + 3 [enumerations field`s]
- ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ -
blazor_generation        - папка Blazor UI
enumerations_generation          - папка перечислений
crud_generation    - папка файлов сервисов backend служб доступа к данным (CRUD) и классов/моделей ответов: интерфейсы (+ реализация) доступа к контексту таблиц базы данных для использования их в UI
××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××
LayerContextPartGen.cs    - разделяемый [public partial class LayerContext : DbContext] класс.
services_di.cs            - [public static class ServicesExtensionDesignerDI].[public static void BuildDesignerServicesDI(this IServiceCollection services)]
