﻿Генератор C# комплекта - ver: 1.0.0+e4b62cc672f43c33e5849139e09d106631f5d4d2 (by © https://github.com/badhitman - @fakegov)
'По умолчанию' `PoUmolchaniyu`
============ 19.07.2024 11:15:21 ============

Перечислений: 2 (элементов всего: 5)
Документов: 1 шт.
	вкладок (всего): 2
	форм (всего): 3
	полей (всего): 9 [simple field`s] + 3 [enumerations field`s]
- ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ - ~ -
enumerations_generation - папка перечислений

crud_generation - папка файлов сервисов backend служб доступа к данным (CRUD) и классов/моделей ответов
	> интерфейсы (+ реализация) доступа к контексту таблиц базы данных для использования их в UI
××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××

LayerContextPartGen.cs - разделяемый [public partial class LayerContext : DbContext] класс.
services_di.cs - [public static class ServicesExtensionDesignerDI].[public static void BuildDesignerServicesDI(this IServiceCollection services)]
